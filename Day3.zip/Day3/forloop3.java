class forloop3
{
public static void main(String args[])
{
for(int i=1;i<=7;i++)
{
System.out.println(i);
if(i==4)
continue;
System.out.println(i);
}
}
}