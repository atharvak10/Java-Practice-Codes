class pattern1
{
public static void main(String args[])
{
for(int i=1;i<=3;i++)  //Row
      { 
	    for(int j=1;j<=3; j++)  // Column
	       { 
		      System.out.print("*");
		   }
		  System.out.println();
	  }	  
}	  
}	