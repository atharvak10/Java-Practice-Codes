import java.util.Scanner;
public class P1
{
	public static void main(String args[])
		{
			char ch='z';
			if (switch(ch))
			{
				case 'a':
				case 'e':
				case 'i':
				case 'o':
				case 'u':
			}
			System.out.println(ch+"is vovel");
			
			else
			System.out.println(ch+"is consonent");
		}
}
			