import java.util.Scanner;

public class Basic6{
	
    public static void main(String[] args) 
    {
        int num, add=0;
        
		Scanner xy = new Scanner(System.in);
        
		System.out.print("kitne number ka add karn hai:");
        
		num = xy.nextInt();
		
        int arr[] = new int[num];
        
		System.out.println("dal de elements:");
        
		for(int i = 0; i < num; i++)
        {
            arr[i] = xy.nextInt();   
            add = add + arr[i];	  
		
        }
        
		System.out.println("Addition of array is :"+add);
    }
}