class Jagged{  

	public static void main(String args[])
	{
		int b1[][]={
						{111,222,333,444},
						{555,666},
						{777,888,999}
					};  
  
		for(int i=0;i<b1.length;i++)
		{  
			for(int j=0;j<b1[i].length;j++)
			{  
				System.out.print(b1[i][j]+" ");  
			}	  
			
		System.out.println();  
		}

			System.out.println(b1[0].length);
			System.out.println(b1[1].length);
			System.out.println(b1[2].length);
	}
}  
