class Person{  
  
	int MobileNo;  
	String Name;  
	String City;
	
	void takeDetails(int M,String N,String C)
	{
		MobileNo=M;
		Name=N;
		City=C;
		
		System.out.println(Name+"  "+City+"  "+MobileNo);
		
	}
	

	
	
}
class New_Person_1
{
	
 public static void main(String args[])
 {
 
 new Person().takeDetails(555,"Sohan","Pune");
  
  }  
}  






















