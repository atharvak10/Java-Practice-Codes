class Basic5 {  
    public static void main(String[] args) {  
          
        char[] A1 = {'S','O','H','A','N','C','D','A','C'};  
        
        char[] A2 = new char[10];  
         
        System.arraycopy(A1,5,A2,0,5);  
          
        System.out.println(String.valueOf(A2));  
    }  
}  