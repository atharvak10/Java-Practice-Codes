class Person{  
  
	int MobileNo;  
	String Name;  
	String City;
	
	void takeDetails(int M,String N,String C)
	{
		MobileNo=M;
		Name=N;
		City=C;
	}
	
	void display()
	{
		System.out.println(Name+"  "+City+"  "+MobileNo);
	
	}
}
class New_Person
{
	
 public static void main(String args[])
 {
 
  Person p1=new Person();  
  Person p2=new Person();
  
  p1.takeDetails(555,"Sohan","Pune");
  p1.display();
  
  p2.takeDetails(666,"Rohan","Mumbai");
  p2.display();

  } 

 
}  






















