public class AnonymousArray{  
  
		static void printArray(int anonymous[])
	{  
		for(int i=0;i<anonymous.length;i++)  
		System.out.println(anonymous[i]);  
	}  
  
		public static void main(String args[]){  
		printArray(new int[]{111,222,333,444});  
	}

}  