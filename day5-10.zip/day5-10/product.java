// 5. Write a Java program that takes two numbers as input and display the product of two numbers.

import java.util.*;

class product
{
	public static void main(String args[])
		{
			Scanner sc = new Scanner(System.in);
			System.out.println(" Enter Two Numbers:");
			System.out.println("Enter First Number:");
			int a = sc.nextInt();
			System.out.println("Enter Second Number:");
			int b = sc.nextInt();
			
			int c=a*b;
			System.out.println(c);
		}
}
			