class ForEach{
  
	public static void main(String args[]){  

			int number[]={111,222,333};  
  
		for(int i:number)  
		System.out.println(i);  
	}
}  