class Employee{  
  
 int Emp_id;  
 String Emp_name;  
   
 public static void main(String args[]){  
   
  Employee emp1=new Employee();  
   
  System.out.println(emp1.Emp_id);  
  
  System.out.println(emp1.Emp_name);  
 }  
}  






















