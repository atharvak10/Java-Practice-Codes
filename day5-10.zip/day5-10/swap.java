//  Write a Java program to swap two variables.

import java.util.*;
class swap
{
	public static void main(String args[])
		{
		Scanner sc = new Scanner(System.in);
			System.out.print("Enter First Number:");
			int a = sc.nextInt();
			System.out.println();
			System.out.print("Enter Second Number:");
			int b = sc.nextInt();
			System.out.println();
			int c;
			System.out.println("you have entered:" +a+"and"+b);
			
			c=a;
			a=b;
			b=c;
			System.out.println("after swap:" +a+"and"+b);
		}
		
}
			
			
			
		
			