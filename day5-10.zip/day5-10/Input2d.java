import java.util.*;   

public class Input2d 
{   
	public static void main(String args[])   
	{   
	
	int row, col;   
	
	Scanner sc=new Scanner(System.in);   

	System.out.print("Number of rows= ");   
	row = sc.nextInt();   

	System.out.print("Enter the Number of column= ");   
	col = sc.nextInt();   
  
	int array[][] = new int[row][col];   
  
	System.out.println("Enter the elements= ");   
  
		for (int i = 0; i < row; i++)   
		{
			for (int j = 0; j < col; j++)   
			{
				array[i][j] = sc.nextInt();   
			}
		}	

	System.out.println("========== Array ============== ");   

		for (int x = 0; x < row; x++)   
		{   
			for (int y = 0; y < col; y++)   
			{
				System.out.print(array[x][y] + " ");   
			}	
			System.out.println();  
		}	
		 
	}   
}    