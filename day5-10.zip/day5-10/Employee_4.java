class Employee{  
  
	int Emp_Id;  
	String Emp_Name;  
	static String Employer="CDAC";
}
class Employee_4
{
	
 public static void main(String args[])
 {
 
  Employee emp1=new Employee();  
  Employee emp2=new Employee();
  
  emp1.Emp_Id=555;
  emp1.Emp_Name="Sohan";
  
  emp2.Emp_Id=777;
  emp2.Emp_Name="Rohan";
  
  System.out.println("==== Employee Details ====");  
  
  System.out.println("1. ID= "+emp1.Emp_Id+" "+"Name= "+emp1.Emp_Name+" "+"Employer= "+emp1.Employer);
  System.out.println("2. ID= "+emp2.Emp_Id+" "+"Name= "+emp2.Emp_Name+" "+"Employer= "+emp2.Employer);
   
   Employee emp3=new Employee();
   emp3.Employer="CDAC_JUHU";
   
   System.out.println("1. ID= "+emp1.Emp_Id+" "+"Name= "+emp1.Emp_Name+" "+"Employer= "+emp1.Employer);
   System.out.println("2. ID= "+emp2.Emp_Id+" "+"Name= "+emp2.Emp_Name+" "+"Employer= "+emp2.Employer);
 }  
}  






















