import java.util.*;
import java.lang.*;
class input2
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 integers to Swap:");
		int i= sc.nextInt();
		int j= sc.nextInt();
		int temp;
		
		System.out.println("Before Swapping :");
		System.out.println("Value of i :"+i);
		System.out.println("Value of j :"+j);
		
		// i=10 and j=15
		
		i=i+j; // i=10+15=25
		j=i-j; // j=25-15=10
		i=i-j; // i=25-10=15
		
		System.out.println("After Swapping :");
		System.out.println("Value of i :"+i);
		System.out.println("Value of j :"+j);
		
	}
}