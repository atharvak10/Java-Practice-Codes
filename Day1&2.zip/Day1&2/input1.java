import java.util.*;
import java.lang.*;
class input1
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 integers to Swap:");
		int i= sc.nextInt();
		int j= sc.nextInt();
		int temp;
		
		System.out.println("Before Swapping :");
		System.out.println("Value of i :"+i);
		System.out.println("Value of j :"+j);
		
		temp=i;
		i=j;
		j=temp;
		
		System.out.println("After Swapping :");
		System.out.println("Value of i :"+i);
		System.out.println("Value of j :"+j);
		
	}
}