public class Ifelse
{
public static void main(String args[])
{
int a=50;
if(a>30)
System.out.println("A is greater");
else
System.out.println("A is small");
}
}