import java.lang.*;
class conditional
{
public static void main(String args[])
{
int a=50,b=60;
int res = (a>b)? a : b;
System.out.println("Answer = "+res);
}
}