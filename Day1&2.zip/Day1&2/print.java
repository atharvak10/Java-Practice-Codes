class print 
{
	public static void main(String args[])
	{
		System.out.println("Welcome ");
		System.out.print("Kharghar And  ");
		System.out.println("Juhu ");
	}
}
