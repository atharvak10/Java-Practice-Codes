public class Datatype
{
public static void main(String args[])
{
boolean a = true;
System.out.println(a);
char b = 'A';
System.out.println(b);
byte c = 105;
System.out.println(c);
short d = 199;
System.out.println(d);
int e = 1234;
System.out.println(e);
long f = 123456789L;
System.out.println(f);
float g = 45.67F;
System.out.println(g);
double h = 12.3456D;
System.out.println(h);
}
}