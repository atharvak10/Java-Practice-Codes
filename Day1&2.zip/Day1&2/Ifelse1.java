public class Ifelse1
{
public static void main(String args[])
{
int a=30;
if(a>30)
System.out.println("A is greater");
else
if(a==30)
System.out.println("A is equal");
else 
System.out.println("A is small");
}
}