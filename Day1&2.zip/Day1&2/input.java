import java.util.Scanner;
class input
{
public static void main(String args[])
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter 2 Integers:");
int i= sc.nextInt();
int j= sc.nextInt();
int k= i+j;
int l= i-j;
int m= i*j;
System.out.println("Value of K is :"+k);
System.out.println("Value of L is :"+l);
System.out.println("Value of M is :"+m);
}
}
