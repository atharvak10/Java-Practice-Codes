public class argument
{
  public static void main(String args[])
  {
	  String s1 = args[0];
	  String s2 = args[1];
	  
	  int k,l,m;
	  int i= Integer.parseInt(s1);
	  int j= Integer.parseInt(s2);
	  k=i+j;
	  l=i-j;
	  m=i*j;
	  
	  System.out.println(k);
	  System.out.println(l);
	  System.out.println(m);
  }
}
	  
 
  
